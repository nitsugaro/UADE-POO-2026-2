import java.util.ArrayList;

public class Vuelo {
    private Aeropuerto aeropuertoOrigen;
    private Aeropuerto aeropuertoDestino;
    private ArrayList<Aeropuerto> escalas;
    private Avion avion;
    private Tripulacion tripulacion;
    private ArrayList<Pasajero> pasajeros;

    public Vuelo(Aeropuerto aeropuertoOrigen, Aeropuerto aeropuertoDestino,
                 Avion avion, Tripulacion tripulacion) {
        this.aeropuertoOrigen = aeropuertoOrigen;
        this.aeropuertoDestino = aeropuertoDestino;
        this.avion = avion;
        this.tripulacion = tripulacion;
        this.escalas = new ArrayList<>();
        this.pasajeros = new ArrayList<>();
    }

    public void agregarEscala(Aeropuerto escala) {
        escalas.add(escala);
    }

    public void agregarPasajero(Pasajero pasajero) {
        pasajeros.add(pasajero);
    }

    public Aeropuerto getAeropuertoOrigen() {
        return aeropuertoOrigen;
    }

    public Aeropuerto getAeropuertoDestino() {
        return aeropuertoDestino;
    }

    public ArrayList<Aeropuerto> getEscalas() {
        return escalas;
    }

    public Avion getAvion() {
        return avion;
    }

    public Tripulacion getTripulacion() {
        return tripulacion;
    }

    public ArrayList<Pasajero> getPasajeros() {
        return pasajeros;
    }
}