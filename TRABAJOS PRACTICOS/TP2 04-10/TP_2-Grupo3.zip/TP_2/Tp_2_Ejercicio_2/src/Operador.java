public class Operador extends Persona {
    public Operador(String nombre, String apellido) {
        super(nombre, apellido);
    }
}
