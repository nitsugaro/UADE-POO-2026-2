public class Piloto extends Persona {
    public Piloto(String nombre, String apellido) {
        super(nombre, apellido);
    }
}
