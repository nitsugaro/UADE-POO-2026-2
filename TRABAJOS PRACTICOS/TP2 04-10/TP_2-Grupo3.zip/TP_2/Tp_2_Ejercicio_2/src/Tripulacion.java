import java.util.ArrayList;

public class Tripulacion {
    private ArrayList<Piloto> pilotos;       // 2
    private Operador operador;               // 1
    private ArrayList<Comisario> comisarios; // 2
    private ArrayList<Azafata> azafatas;     // 4

    public Tripulacion(Operador operador) {
        this.operador = operador;
        this.pilotos = new ArrayList<>();
        this.comisarios = new ArrayList<>();
        this.azafatas = new ArrayList<>();
    }

    public void agregarPiloto(Piloto piloto) {
        if (pilotos.size() < 2) {
            pilotos.add(piloto);
        }
    }

    public void agregarComisario(Comisario comisario) {
        if (comisarios.size() < 2) {
            comisarios.add(comisario);
        }
    }

    public void agregarAzafata(Azafata azafata) {
        if (azafatas.size() < 4) {
            azafatas.add(azafata);
        }
    }

    public ArrayList<Piloto> getPilotos() {
        return pilotos;
    }

    public Operador getOperador() {
        return operador;
    }

    public ArrayList<Comisario> getComisarios() {
        return comisarios;
    }

    public ArrayList<Azafata> getAzafatas() {
        return azafatas;
    }
}

