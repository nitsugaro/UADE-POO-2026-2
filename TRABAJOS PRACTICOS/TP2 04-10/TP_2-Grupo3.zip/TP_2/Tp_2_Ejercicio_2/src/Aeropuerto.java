public class Aeropuerto {
    private String nombre;
    private Ciudad ciudad;

    public Aeropuerto(String nombre, Ciudad ciudad) {
        this.nombre = nombre;
        this.ciudad = ciudad;
    }

    public String getNombre() {
        return nombre;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }
}
