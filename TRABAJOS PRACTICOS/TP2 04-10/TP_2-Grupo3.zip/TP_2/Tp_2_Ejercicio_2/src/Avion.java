public class Avion {
    private String codigo;
    private String modelo;

    public Avion(String codigo, String modelo) {
        this.codigo = codigo;
        this.modelo = modelo;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getModelo() {
        return modelo;
    }
}
