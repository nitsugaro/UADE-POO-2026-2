public class Main {
    public static void main(String[] args) {

        Aeropuerto origen = new Aeropuerto("Ezeiza", new Ciudad("Buenos Aires"));
        Aeropuerto destino = new Aeropuerto("Barajas", new Ciudad("Madrid"));
        Aeropuerto escala = new Aeropuerto("Guarulhos", new Ciudad("San Pablo"));

        Avion avion = new Avion("LV-ABC", "Boeing 777");

        Tripulacion tripulacion = new Tripulacion(new Operador("Carlos", "Diaz"));
        tripulacion.agregarPiloto(new Piloto("Juan", "Perez"));
        tripulacion.agregarPiloto(new Piloto("Maria", "Gomez"));
        tripulacion.agregarComisario(new Comisario("Luis", "Fernandez"));
        tripulacion.agregarComisario(new Comisario("Ana", "Lopez"));
        tripulacion.agregarAzafata(new Azafata("Laura", "Martinez"));
        tripulacion.agregarAzafata(new Azafata("Sofia", "Rodriguez"));
        tripulacion.agregarAzafata(new Azafata("Carla", "Sanchez"));
        tripulacion.agregarAzafata(new Azafata("Paula", "Romero"));

        Vuelo vuelo = new Vuelo(origen, destino, avion, tripulacion);
        vuelo.agregarEscala(escala);
        vuelo.agregarPasajero(new Pasajero("Pedro Alvarez", 30111222, "12A"));
        vuelo.agregarPasajero(new Pasajero("Lucia Torres", 35444555, "12B"));

        System.out.println("Origen: " + vuelo.getAeropuertoOrigen().getNombre());
        System.out.println("Destino: " + vuelo.getAeropuertoDestino().getNombre());
        System.out.println("Escalas: " + vuelo.getEscalas().size());
        System.out.println("Avion: " + vuelo.getAvion().getModelo());
        System.out.println("Pilotos: " + vuelo.getTripulacion().getPilotos().size());
        System.out.println("Azafatas: " + vuelo.getTripulacion().getAzafatas().size());
        System.out.println("Pasajeros: " + vuelo.getPasajeros().size());
    }
}