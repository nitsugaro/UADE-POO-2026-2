public class Pasajero {
    private String nombre;
    private int dni;
    private String asiento;

    public Pasajero(String nombre, int dni, String asiento) {
        this.nombre = nombre;
        this.dni = dni;
        this.asiento = asiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getDni() {
        return dni;
    }

    public String getAsiento() {
        return asiento;
    }
}