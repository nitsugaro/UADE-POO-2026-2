public class Comisario extends Persona {
    public Comisario(String nombre, String apellido) {
        super(nombre, apellido);
    }
}
