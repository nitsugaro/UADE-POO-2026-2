public class Azafata extends Persona {
    public Azafata(String nombre, String apellido) {
        super(nombre, apellido);
    }
}