import java.util.ArrayList;

public class Sistema {
    private ArrayList<Producto> productos;
    private ArrayList<OrdenCompra> ordenes;

    public Sistema() {
        this.productos = new ArrayList<>();
        this.ordenes = new ArrayList<>();
    }

    public void altaProducto(Producto producto) {
        productos.add(producto);
    }

    public void generarOrden(OrdenCompra orden) {
        ordenes.add(orden);
    }

    public void consultarOrdenesPorProveedor(String dni) {
        System.out.println("Ordenes del proveedor:");
        int total = 0;
        for (OrdenCompra orden : ordenes) {
            if (orden.getProveedor().getDni().equals(dni)) {
                System.out.println("Proveedor: " + orden.getProveedor().getNombre() + " - Orden: " + orden.getCodigoCompra());
                total++;
            }
        }
        System.out.println("Total de ordenes: " + total);
    }
}