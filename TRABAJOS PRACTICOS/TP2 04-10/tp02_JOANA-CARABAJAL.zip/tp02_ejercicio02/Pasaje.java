package tp02_ejercicio02;

public class Pasaje {

    private int numero;
    private Vuelo vuelo;
    private Pasajero pasajero;
    private Asiento asiento;

    public Pasaje(int numero, Vuelo vuelo, Pasajero pasajero, Asiento asiento) {
        this.numero = numero;
        this.vuelo = vuelo;
        this.pasajero = pasajero;
        this.asiento = asiento;
    }

    public int getNumero() {
        return numero;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public Asiento getAsiento() {
        return asiento;
    }

    @Override
    public String toString() {
        return "Pasaje Nº " + numero + " - " + pasajero.getNombre() + " " + pasajero.getApellido()
                + " - Asiento " + asiento + " - Vuelo " + vuelo.getCodigo();
    }
}
