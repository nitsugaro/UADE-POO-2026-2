package tp02_ejercicio02;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Vuelo {

    private String codigo;
    private LocalDateTime fechaHoraSalida;
    private LocalDateTime fechaHoraLlegada;
    private Aeropuerto origen;
    private Aeropuerto destino;
    private List<Aeropuerto> escalas;
    private Avion avion;
    private Tripulacion tripulacion;
    private List<Pasaje> pasajes;

    public Vuelo(String codigo, Aeropuerto origen, Aeropuerto destino,
                 Avion avion, Tripulacion tripulacion,
                 LocalDateTime salida, LocalDateTime llegada) {
        this.codigo = codigo;
        this.origen = origen;
        this.destino = destino;
        this.avion = avion;
        this.tripulacion = tripulacion;
        this.fechaHoraSalida = salida;
        this.fechaHoraLlegada = llegada;
        this.escalas = new ArrayList<>();
        this.pasajes = new ArrayList<>();
    }

    public void agregarEscala(Aeropuerto a) {
        escalas.add(a);
    }

    public boolean tieneEscalas() {
        return !escalas.isEmpty();
    }

    public Pasaje venderPasaje(Pasajero p, Asiento a) {
        if (!avion.getAsientos().contains(a)) {
            throw new IllegalArgumentException("El asiento " + a + " no pertenece al avión de este vuelo");
        }
        for (Pasaje pasaje : pasajes) {
            if (pasaje.getAsiento().equals(a)) {
                throw new IllegalStateException("El asiento " + a + " ya está ocupado en el vuelo " + codigo);
            }
        }
        Pasaje nuevo = new Pasaje(pasajes.size() + 1, this, p, a);
        pasajes.add(nuevo);
        return nuevo;
    }

    public String getCodigo() {
        return codigo;
    }

    public LocalDateTime getFechaHoraSalida() {
        return fechaHoraSalida;
    }

    public LocalDateTime getFechaHoraLlegada() {
        return fechaHoraLlegada;
    }

    public Aeropuerto getOrigen() {
        return origen;
    }

    public Aeropuerto getDestino() {
        return destino;
    }

    public List<Aeropuerto> getEscalas() {
        return escalas;
    }

    public Avion getAvion() {
        return avion;
    }

    public Tripulacion getTripulacion() {
        return tripulacion;
    }

    public List<Pasaje> getPasajes() {
        return pasajes;
    }

    @Override
    public String toString() {
        return "Vuelo " + codigo + ": " + origen.getCodigo() + " -> " + destino.getCodigo()
                + " | Salida: " + fechaHoraSalida + " | Llegada: " + fechaHoraLlegada
                + " | Escalas: " + escalas.size();
    }
}
