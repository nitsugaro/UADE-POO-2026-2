package tp02_ejercicio02;

public class Comisario extends Tripulante {

    public Comisario(String nombre, String apellido, String dni, String legajo) {
        super(nombre, apellido, dni, legajo);
    }
}
