package tp02_ejercicio02;

public class Azafata extends Tripulante {

    public Azafata(String nombre, String apellido, String dni, String legajo) {
        super(nombre, apellido, dni, legajo);
    }
}
