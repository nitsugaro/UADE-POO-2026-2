package tp02_ejercicio02;

public class Piloto extends Tripulante {

    private String licencia;
    private int horasDeVuelo;

    public Piloto(String nombre, String apellido, String dni, String legajo,
                  String licencia, int horasDeVuelo) {
        super(nombre, apellido, dni, legajo);
        this.licencia = licencia;
        this.horasDeVuelo = horasDeVuelo;
    }

    public String getLicencia() {
        return licencia;
    }

    public int getHorasDeVuelo() {
        return horasDeVuelo;
    }

    @Override
    public String toString() {
        return super.toString() + " - Licencia: " + licencia + " - Horas de vuelo: " + horasDeVuelo;
    }
}
