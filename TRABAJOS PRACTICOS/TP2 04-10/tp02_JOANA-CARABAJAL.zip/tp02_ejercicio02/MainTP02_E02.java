package tp02_ejercicio02;


import java.time.LocalDateTime;

public class MainTP02_E02{

    public static void main(String[] args) {

        // Ciudades y aeropuertos
        Ciudad buenosAires = new Ciudad("Buenos Aires", "Argentina");
        Ciudad saoPaulo = new Ciudad("São Paulo", "Brasil");
        Ciudad madrid = new Ciudad("Madrid", "España");

        Aeropuerto eze = new Aeropuerto("EZE", "Ezeiza", buenosAires);
        Aeropuerto aep = new Aeropuerto("AEP", "Aeroparque Jorge Newbery", buenosAires);
        Aeropuerto gru = new Aeropuerto("GRU", "Guarulhos", saoPaulo);
        Aeropuerto mad = new Aeropuerto("MAD", "Barajas", madrid);

        System.out.println("Aeropuertos en Buenos Aires: " + buenosAires.getAeropuertos().size());

        // Avión con 12 asientos (filas 1 a 3, letras A a D)
        Avion avion = new Avion("LV-ABC", "Boeing 787");
        for (int fila = 1; fila <= 3; fila++) {
            for (char letra = 'A'; letra <= 'D'; letra++) {
                avion.agregarAsiento(new Asiento(fila, letra));
            }
        }
        System.out.println(avion);

        // Tripulación: 2 pilotos, 1 operador, 2 comisarios, 4 azafatas
        Piloto piloto1 = new Piloto("Carlos", "Gómez", "20111222", "T001", "LIC-100", 5200);
        Piloto piloto2 = new Piloto("Laura", "Pérez", "22333444", "T002", "LIC-101", 3100);
        OperadorComunicaciones operador = new OperadorComunicaciones("Martín", "Ruiz", "25444555", "T003", "CERT-55");
        Comisario comisario1 = new Comisario("Ana", "López", "27555666", "T004");
        Comisario comisario2 = new Comisario("Diego", "Silva", "28666777", "T005");
        Azafata azafata1 = new Azafata("Sofía", "Díaz", "30777888", "T006");
        Azafata azafata2 = new Azafata("Julieta", "Torres", "31888999", "T007");
        Azafata azafata3 = new Azafata("Camila", "Romero", "32999000", "T008");
        Azafata azafata4 = new Azafata("Valentina", "Acosta", "33000111", "T009");

        Tripulacion tripulacion = new Tripulacion(piloto1, piloto2, operador,
                comisario1, comisario2,
                azafata1, azafata2, azafata3, azafata4);
        System.out.println("¿Tripulación completa? " + tripulacion.estaCompleta());

        // Vuelo EZE -> MAD con escala en GRU
        Vuelo vuelo = new Vuelo("AR1130", eze, mad, avion, tripulacion,
                LocalDateTime.of(2026, 10, 15, 22, 30),
                LocalDateTime.of(2026, 10, 16, 14, 45));
        vuelo.agregarEscala(gru);
        System.out.println(vuelo);
        System.out.println("¿Tiene escalas? " + vuelo.tieneEscalas());

        // Aerolínea
        Aerolinea aerolinea = new Aerolinea("Aerolíneas Demo");
        aerolinea.agregarAvion(avion);
        aerolinea.agregarVuelo(vuelo);
        System.out.println(aerolinea);

        // Venta de pasajes
        Pasajero pasajero1 = new Pasajero("Juan", "Martínez", "35111222", "AAA111");
        Pasajero pasajero2 = new Pasajero("María", "Fernández", "36222333", "BBB222");

        Pasaje pasaje1 = vuelo.venderPasaje(pasajero1, avion.getAsientos().get(0));
        Pasaje pasaje2 = vuelo.venderPasaje(pasajero2, avion.getAsientos().get(5));
        System.out.println(pasaje1);
        System.out.println(pasaje2);

        // Intento de vender un asiento ya ocupado
        try {
            vuelo.venderPasaje(pasajero2, avion.getAsientos().get(0));
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("Pasajes vendidos en el vuelo: " + vuelo.getPasajes().size());
    }
}
