package tp02_ejercicio02;

public class Pasajero extends Persona {

    private String pasaporte;

    public Pasajero(String nombre, String apellido, String dni, String pasaporte) {
        super(nombre, apellido, dni);
        this.pasaporte = pasaporte;
    }

    public String getPasaporte() {
        return pasaporte;
    }

    @Override
    public String toString() {
        return super.toString() + " - Pasaporte: " + pasaporte;
    }
}
