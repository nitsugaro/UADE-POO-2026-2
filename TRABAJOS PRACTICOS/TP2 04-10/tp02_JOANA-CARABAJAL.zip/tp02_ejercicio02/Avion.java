package tp02_ejercicio02;

import java.util.ArrayList;
import java.util.List;

public class Avion {

    private String matricula;
    private String modelo;
    private int capacidad;
    private List<Asiento> asientos;

    public Avion(String matricula, String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.capacidad = 0;
        this.asientos = new ArrayList<>();
    }

    public void agregarAsiento(Asiento a) {
        asientos.add(a);
        capacidad++;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public List<Asiento> getAsientos() {
        return asientos;
    }

    @Override
    public String toString() {
        return modelo + " (" + matricula + ") - Capacidad: " + capacidad;
    }
}
