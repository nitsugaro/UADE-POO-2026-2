package tp02_ejercicio02;

public class Asiento {

    private int fila;
    private char letra;

    public Asiento(int fila, char letra) {
        this.fila = fila;
        this.letra = letra;
    }

    public int getFila() {
        return fila;
    }

    public char getLetra() {
        return letra;
    }

    @Override
    public String toString() {
        return fila + "" + letra;
    }
}
