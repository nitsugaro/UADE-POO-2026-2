package tp02_ejercicio02;

import java.util.ArrayList;
import java.util.List;

public class Aerolinea {

    private String nombre;
    private List<Vuelo> vuelos;
    private List<Avion> aviones;

    public Aerolinea(String nombre) {
        this.nombre = nombre;
        this.vuelos = new ArrayList<>();
        this.aviones = new ArrayList<>();
    }

    public void agregarVuelo(Vuelo v) {
        vuelos.add(v);
    }

    public void agregarAvion(Avion a) {
        aviones.add(a);
    }

    public String getNombre() {
        return nombre;
    }

    public List<Vuelo> getVuelos() {
        return vuelos;
    }

    public List<Avion> getAviones() {
        return aviones;
    }

    @Override
    public String toString() {
        return nombre + " - Vuelos: " + vuelos.size() + " - Aviones: " + aviones.size();
    }
}
