package tp02_ejercicio02;

import java.util.ArrayList;
import java.util.List;

public class Ciudad {

    private String nombre;
    private String pais;
    private List<Aeropuerto> aeropuertos;

    public Ciudad(String nombre, String pais) {
        this.nombre = nombre;
        this.pais = pais;
        this.aeropuertos = new ArrayList<>();
    }

    public void agregarAeropuerto(Aeropuerto a) {
        aeropuertos.add(a);
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    public List<Aeropuerto> getAeropuertos() {
        return aeropuertos;
    }

    @Override
    public String toString() {
        return nombre + ", " + pais;
    }
}
