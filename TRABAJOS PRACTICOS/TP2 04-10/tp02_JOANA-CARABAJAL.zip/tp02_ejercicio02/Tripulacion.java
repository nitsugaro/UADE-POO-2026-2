package tp02_ejercicio02;

import java.util.ArrayList;
import java.util.List;

public class Tripulacion {

    private List<Piloto> pilotos;
    private OperadorComunicaciones operador;
    private List<Comisario> comisarios;
    private List<Azafata> azafatas;

    public Tripulacion(Piloto p1, Piloto p2,
                       OperadorComunicaciones op,
                       Comisario c1, Comisario c2,
                       Azafata a1, Azafata a2, Azafata a3, Azafata a4) {
        this.pilotos = new ArrayList<>();
        this.pilotos.add(p1);
        this.pilotos.add(p2);

        this.operador = op;

        this.comisarios = new ArrayList<>();
        this.comisarios.add(c1);
        this.comisarios.add(c2);

        this.azafatas = new ArrayList<>();
        this.azafatas.add(a1);
        this.azafatas.add(a2);
        this.azafatas.add(a3);
        this.azafatas.add(a4);
    }

    public boolean estaCompleta() {
        return pilotos.size() == 2
                && !pilotos.contains(null)
                && operador != null
                && comisarios.size() == 2
                && !comisarios.contains(null)
                && azafatas.size() == 4
                && !azafatas.contains(null);
    }

    public List<Piloto> getPilotos() {
        return pilotos;
    }

    public OperadorComunicaciones getOperador() {
        return operador;
    }

    public List<Comisario> getComisarios() {
        return comisarios;
    }

    public List<Azafata> getAzafatas() {
        return azafatas;
    }
}
