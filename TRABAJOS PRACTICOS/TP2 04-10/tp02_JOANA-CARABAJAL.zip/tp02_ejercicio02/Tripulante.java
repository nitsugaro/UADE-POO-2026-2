package tp02_ejercicio02;

public abstract class Tripulante extends Persona {

    private String legajo;

    public Tripulante(String nombre, String apellido, String dni, String legajo) {
        super(nombre, apellido, dni);
        this.legajo = legajo;
    }

    public String getLegajo() {
        return legajo;
    }

    @Override
    public String toString() {
        return super.toString() + " - Legajo: " + legajo;
    }
}
