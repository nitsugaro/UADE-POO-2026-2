package tp02_ejercicio02;

public class Aeropuerto {

    private String codigo;
    private String nombre;
    private Ciudad ciudad;

    public Aeropuerto(String codigo, String nombre, Ciudad ciudad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ciudad = ciudad;
        ciudad.agregarAeropuerto(this);
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }

    @Override
    public String toString() {
        return nombre + " (" + codigo + ") - " + ciudad;
    }
}
