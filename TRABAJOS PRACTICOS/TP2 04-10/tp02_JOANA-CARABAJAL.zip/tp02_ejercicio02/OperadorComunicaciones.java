package tp02_ejercicio02;

public class OperadorComunicaciones extends Tripulante {

    private String certificacion;

    public OperadorComunicaciones(String nombre, String apellido, String dni, String legajo,
                                  String certificacion) {
        super(nombre, apellido, dni, legajo);
        this.certificacion = certificacion;
    }

    public String getCertificacion() {
        return certificacion;
    }

    @Override
    public String toString() {
        return super.toString() + " - Certificación: " + certificacion;
    }
}
