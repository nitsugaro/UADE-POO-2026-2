package tp02_ejercicio01;

public class DetalleOrden {
    private Producto producto;
    private Integer cantidad;

    public DetalleOrden(Producto producto, Integer cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public Double calcularSubtotal() {
        return this.producto.getPrecio() * this.cantidad;
    }

    public Producto getProducto() {
        return producto;
    }

    public Integer getCantidad() {
        return cantidad;
    }
}
