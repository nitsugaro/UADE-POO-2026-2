package tp02_ejercicio01;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MainTP2_E01 {
    public static void main(String[] args) {
        SistemaCompras sistema = new SistemaCompras();

        // 1. Alta de productos
        Producto prod1 = new Producto("P001", "Notebook", 1500.0);
        Producto prod2 = new Producto("P002", "Mouse", 25.0);
        sistema.altaProducto(prod1);
        sistema.altaProducto(prod2);

        // 2. Agregar proveedor
        Proveedor prov1 = new Proveedor("30123456789", "Tech Supplier S.A.");
        sistema.agregarProveedor(prov1);

        // 3. Preparar detalles para la orden
        List<DetalleOrden> detalles = new ArrayList<>();
        detalles.add(new DetalleOrden(prod1, 2));
        detalles.add(new DetalleOrden(prod2, 5));

        // 4. Generar la orden de compra
        sistema.generarOrdenDeCompra("30123456789", LocalDate.now(), detalles);

        // 5. Consultar órdenes del proveedor
        System.out.println("--- Consulta de Órdenes ---");
        sistema.consultarOrdenesPorProveedor("30123456789");
    }
}
