package tp02_ejercicio01;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrdenDeCompra {
    private Integer numero;
    private LocalDate fecha;
    private Proveedor proveedor;
    private List<DetalleOrden> detalles;

    public OrdenDeCompra(Integer numero, LocalDate fecha, Proveedor proveedor) {
        this.numero = numero;
        this.fecha = fecha;
        this.proveedor = proveedor;
        this.detalles = new ArrayList<>();
    }

    public void agregarDetalle(Producto producto, Integer cant) {
        DetalleOrden detalle = new DetalleOrden(producto, cant);
        this.detalles.add(detalle);
    }

    public Double calcularTotal() {
        Double total = 0.0;
        for (DetalleOrden detalle : detalles) {
            total += detalle.calcularSubtotal();
        }
        return total;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }
}
