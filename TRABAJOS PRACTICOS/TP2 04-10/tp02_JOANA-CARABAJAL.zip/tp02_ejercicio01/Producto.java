package tp02_ejercicio01;

public class Producto {
    private String codigo;
    private String desc;
    private Double precio;

    public Producto(String codigo, String desc, Double precio) {
        this.codigo = codigo;
        this.desc = desc;
        this.precio = precio;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getDesc() {
        return desc;
    }

    public Double getPrecio() {
        return precio;
    }
}
