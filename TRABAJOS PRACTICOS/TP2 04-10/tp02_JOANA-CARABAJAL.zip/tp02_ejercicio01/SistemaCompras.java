package tp02_ejercicio01;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SistemaCompras {
    private List<Producto> productos;
    private List<Proveedor> proveedores;
    private List<OrdenDeCompra> ordenes;

    public SistemaCompras() {
        this.productos = new ArrayList<>();
        this.proveedores = new ArrayList<>();
        this.ordenes = new ArrayList<>();
    }

    public void altaProducto(Producto p) {
        this.productos.add(p);
    }

    public void agregarProveedor(Proveedor p) {
        this.proveedores.add(p);
    }

    public void generarOrdenDeCompra(String dniProv, LocalDate fecha, List<DetalleOrden> detalles) {
        Proveedor provEncontrado = null;
        for (Proveedor p : proveedores) {
            if (p.getDni().equals(dniProv)) {
                provEncontrado = p;
                break;
            }
        }

        if (provEncontrado != null) {
            int numeroOrden = this.ordenes.size() + 1;
            OrdenDeCompra nuevaOrden = new OrdenDeCompra(numeroOrden, fecha, provEncontrado);

            // Verificamos la existencia de cada producto en el catálogo del sistema
            for (DetalleOrden detalle : detalles) {
                boolean productoExiste = false;
                for (Producto p : productos) {
                    if (p.getCodigo().equals(detalle.getProducto().getCodigo())) {
                        productoExiste = true;
                        break;
                    }
                }

                if (productoExiste) {
                    nuevaOrden.agregarDetalle(detalle.getProducto(), detalle.getCantidad());
                } else {
                    System.out.println("Error: Producto con código " + detalle.getProducto().getCodigo() + " no existe. Se omitirá.");
                }
            }

            this.ordenes.add(nuevaOrden);
        } else {
            System.out.println("Error: Proveedor no encontrado.");
        }
    }

    public void consultarOrdenesPorProveedor(String dni) {
        Proveedor provEncontrado = null;
        for (Proveedor p : proveedores) {
            if (p.getDni().equals(dni)) {
                provEncontrado = p;
                break;
            }
        }

        if (provEncontrado == null) {
            System.out.println("Proveedor no registrado.");
            return;
        }

        System.out.println("Proveedor: " + provEncontrado.getNombre());
        Double sumaTotal = 0.0;

        for (OrdenDeCompra orden : ordenes) {
            if (orden.getProveedor().getDni().equals(dni)) {
                Double totalOrden = orden.calcularTotal();
                System.out.println("Orden Total: $" + totalOrden);
                sumaTotal += totalOrden;
            }
        }
        System.out.println("Total acumulado de órdenes: $" + sumaTotal);
    }
}