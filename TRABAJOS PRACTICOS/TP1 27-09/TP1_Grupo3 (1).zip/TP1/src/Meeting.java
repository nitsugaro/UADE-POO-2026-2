package grupo3.tp1.uade;

/**
 * Representa una reunion con su informacion basica.
 */
public class Meeting {

    private String location;
    private String participants;
    private String topic;
    private int duration; // duracion en minutos

    // Crea una nueva reunion con todos sus datos
    public Meeting(String location, String participants, String topic, int duration) throws InvalidInputException {
        this.location = location;
        this.participants = participants;
        this.topic = topic;
        this.duration = duration;
        validate();
    }

    // Verifica que los datos de la reunion sean validos
    public void validate() throws InvalidInputException {
        if (location == null || location.trim().isEmpty()) {
            throw new InvalidInputException("El lugar no puede estar vacio.");
        }
        if (participants == null || participants.trim().isEmpty()) {
            throw new InvalidInputException("Los participantes no pueden estar vacios.");
        }
        if (topic == null || topic.trim().isEmpty()) {
            throw new InvalidInputException("El tema no puede estar vacio.");
        }
        if (duration <= 0) {
            throw new InvalidInputException("La duracion debe ser mayor a 0 minutos.");
        }
    }

    public String getLocation() {
        return location;
    }

    public String getParticipants() {
        return participants;
    }

    public String getTopic() {
        return topic;
    }

    public int getDuration() {
        return duration;
    }

    // Devuelve un texto legible con todos los detalles de la reunion
    @Override
    public String toString() {
        return "Lugar: " + location
                + " | Participantes: " + participants
                + " | Tema: " + topic
                + " | Duracion: " + duration + " minutos";
    }
}
