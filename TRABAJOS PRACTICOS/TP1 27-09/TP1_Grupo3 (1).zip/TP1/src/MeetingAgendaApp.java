package grupo3.tp1.uade;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Aplicacion de consola para la agenda personal de reuniones.
 */
public class MeetingAgendaApp {

    private Agenda agenda;
    private Scanner scanner;

    public MeetingAgendaApp() {
        agenda = new Agenda();
        scanner = new Scanner(System.in);
    }

    public void run() {
        int option;

        do {
            showMenu();
            option = readInt("Seleccione una opcion: ");

            switch (option) {
                case 1:
                    addMeeting();
                    break;
                case 2:
                    listMeetings();
                    break;
                case 3:
                    searchMeetings();
                    break;
                case 0:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } while (option != 0);
    }

    private void showMenu() {
        System.out.println();
        System.out.println("--- Agenda de Reuniones ---");
        System.out.println("1. Agregar reunion");
        System.out.println("2. Listar reuniones");
        System.out.println("3. Buscar reunion por tema");
        System.out.println("0. Volver al menu principal");
    }

    private void addMeeting() {
        System.out.println();
        System.out.println("--- Nueva Reunion ---");

        try {
            System.out.print("Lugar: ");
            String location = scanner.nextLine();

            System.out.print("Participantes: ");
            String participants = scanner.nextLine();

            System.out.print("Tema: ");
            String topic = scanner.nextLine();

            int duration = readPositiveInt("Duracion (en minutos): ");

            Meeting meeting = new Meeting(location, participants, topic, duration);
            agenda.addMeeting(meeting);

            System.out.println("Reunion agregada correctamente.");
        } catch (InvalidInputException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void listMeetings() {
        System.out.println();
        System.out.println("--- Listado de Reuniones ---");

        if (agenda.isEmpty()) {
            System.out.println("No hay reuniones registradas.");
            return;
        }

        ArrayList<Meeting> meetings = agenda.getMeetings();
        for (int i = 0; i < meetings.size(); i++) {
            System.out.println((i + 1) + ". " + meetings.get(i));
        }
    }

    private void searchMeetings() {
        System.out.println();
        System.out.print("Ingrese texto a buscar en el tema: ");
        String text = scanner.nextLine();

        try {
            ArrayList<Meeting> results = agenda.searchByTopic(text);

            if (results.isEmpty()) {
                throw new NotFoundException("No se encontraron reuniones con ese tema.");
            }

            System.out.println("--- Resultados de la busqueda ---");
            for (int i = 0; i < results.size(); i++) {
                System.out.println((i + 1) + ". " + results.get(i));
            }
        } catch (InvalidInputException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    // Lee un numero entero positivo del usuario
    private int readPositiveInt(String message) throws InvalidInputException {
        int value = readInt(message);
        if (value <= 0) {
            throw new InvalidInputException("La duracion debe ser mayor a 0 minutos.");
        }
        return value;
    }

    // Lee un numero entero del usuario y maneja entradas invalidas
    private int readInt(String message) {
        int value;
        while (true) {
            System.out.print(message);
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                scanner.nextLine(); // limpia la linea despues del numero
                return value;
            } else {
                System.out.println("Debe ingresar un numero valido.");
                scanner.nextLine(); // limpia la entrada invalida
            }
        }
    }
}
