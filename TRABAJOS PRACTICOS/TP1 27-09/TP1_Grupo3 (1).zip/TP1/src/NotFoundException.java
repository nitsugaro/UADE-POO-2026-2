package grupo3.tp1.uade;

/**
 * Excepcion cuando no se encuentra un elemento buscado (reunion, vuelo, etc.).
 */
public class NotFoundException extends Exception {

    public NotFoundException(String message) {
        super(message);
    }
}
