package grupo3.tp1.uade;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Sistema de reserva de vuelos por menu para viajeros de ultimo momento.
 */
public class FlightReservationApp {

    private static ArrayList<Flight> flights = new ArrayList<>();
    private static ArrayList<Reservation> reservations = new ArrayList<>();
    private static int nextReservationId = 1;

    // Vuelos de ejemplo cargados al iniciar la aplicacion
    static {
        try {
            flights.add(new Flight("AR101", "Buenos Aires", "2026-09-10", "Primera Clase", true, 150000));
            flights.add(new Flight("AR102", "Buenos Aires", "2026-09-15", "Turista", false, 80000));
            flights.add(new Flight("AR103", "Buenos Aires", "2026-09-22", "Economica", true, 65000));
            flights.add(new Flight("LA201", "Miami", "2026-09-12", "Turista", true, 95000));
            flights.add(new Flight("LA202", "Miami", "2026-09-20", "Economica", false, 70000));
            flights.add(new Flight("IB301", "Madrid", "2026-09-18", "Primera Clase", true, 200000));
            flights.add(new Flight("IB302", "Madrid", "2026-09-25", "Turista", false, 85000));
            flights.add(new Flight("IB303", "Madrid", "2026-09-28", "Economica", false, 72000));
        } catch (InvalidInputException e) {
            System.out.println("Error al cargar vuelos de ejemplo: " + e.getMessage());
        }
    }

    /**
     * Punto de entrada principal llamado desde el menu de Tp1.
     */
    public static void run(Scanner scanner) {
        System.out.println("\n=== Sistema de Reserva de Vuelos ===");
        System.out.println("Busqueda de vuelos de ultimo momento\n");

        try {
            // Pide los criterios de busqueda
            System.out.print("Ciudad de destino: ");
            String destination = scanner.nextLine().trim();
            validateDestination(destination);

            System.out.print("Fecha minima de salida (AAAA-MM-DD): ");
            String earliestDate = scanner.nextLine().trim();
            validateDate(earliestDate);

            System.out.print("Fecha maxima de salida (AAAA-MM-DD): ");
            String latestDate = scanner.nextLine().trim();
            validateDate(latestDate);
            validateDateRange(earliestDate, latestDate);

            String travelClass = askTravelClass(scanner);
            if (travelClass == null) {
                System.out.println("Clase invalida. Intente nuevamente mas tarde.");
                return;
            }

            boolean wantsSmoker = askSmokerPreference(scanner);

            // Busca vuelos que coincidan
            ArrayList<Flight> matches = searchFlights(destination, earliestDate, latestDate, travelClass, wantsSmoker);

            if (matches.isEmpty()) {
                throw new NotFoundException("No hay vuelos disponibles que coincidan con su busqueda.");
            }

            // Muestra las opciones y deja que el usuario elija una
            showFlights(matches);

            System.out.print("\nSeleccione un vuelo (0 para cancelar): ");
            int choice = readInt(scanner);

            if (choice <= 0 || choice > matches.size()) {
                System.out.println("\nNo selecciono ningun vuelo.");
                System.out.println("Le invitamos a consultar nuevamente mas tarde.");
                return;
            }

            Flight selectedFlight = matches.get(choice - 1);

            // Pide los datos del pasajero y crea la reserva
            Passenger passenger = askPassengerData(scanner);
            Reservation reservation = new Reservation(nextReservationId++, selectedFlight, passenger, wantsSmoker);
            reservations.add(reservation);
            selectedFlight.setAvailable(false);

            printTicket(reservation);
        } catch (InvalidInputException e) {
            System.out.println("\nError: " + e.getMessage());
            System.out.println("Le invitamos a consultar nuevamente mas tarde.");
        } catch (NotFoundException e) {
            System.out.println("\n" + e.getMessage());
            System.out.println("Le invitamos a consultar nuevamente mas tarde.");
        }
    }

    // Verifica que el destino no este vacio
    private static void validateDestination(String destination) throws InvalidInputException {
        if (destination == null || destination.isEmpty()) {
            throw new InvalidInputException("Debe ingresar una ciudad de destino.");
        }
    }

    // Verifica que la fecha tenga formato AAAA-MM-DD
    private static void validateDate(String date) throws InvalidInputException {
        if (date == null || date.length() != 10) {
            throw new InvalidInputException("La fecha debe tener formato AAAA-MM-DD.");
        }
        if (date.charAt(4) != '-' || date.charAt(7) != '-') {
            throw new InvalidInputException("La fecha debe tener formato AAAA-MM-DD.");
        }

        try {
            int year = Integer.parseInt(date.substring(0, 4));
            int month = Integer.parseInt(date.substring(5, 7));
            int day = Integer.parseInt(date.substring(8, 10));

            if (year <= 0 || month < 1 || month > 12 || day < 1 || day > 31) {
                throw new InvalidInputException("La fecha ingresada no es valida.");
            }
        } catch (NumberFormatException e) {
            throw new InvalidInputException("La fecha debe contener solo numeros en formato AAAA-MM-DD.");
        }
    }

    // Verifica que la fecha minima no sea posterior a la maxima
    private static void validateDateRange(String earliestDate, String latestDate) throws InvalidInputException {
        if (earliestDate.compareTo(latestDate) > 0) {
            throw new InvalidInputException("La fecha minima no puede ser posterior a la fecha maxima.");
        }
    }

    // Muestra el menu de clases y devuelve el nombre de la clase elegida
    private static String askTravelClass(Scanner scanner) {
        System.out.println("\nClases disponibles:");
        System.out.println("1 - Primera Clase");
        System.out.println("2 - Turista");
        System.out.println("3 - Economica");
        System.out.print("Seleccione clase: ");

        int option = readInt(scanner);

        switch (option) {
            case 1:
                return "Primera Clase";
            case 2:
                return "Turista";
            case 3:
                return "Economica";
            default:
                return null;
        }
    }

    // Pregunta si el usuario prefiere la seccion de fumadores
    private static boolean askSmokerPreference(Scanner scanner) {
        System.out.print("\nPrefiere seccion fumadores? (s/n): ");
        String answer = scanner.nextLine().trim().toLowerCase();
        return answer.equals("s") || answer.equals("si");
    }

    // Filtra vuelos segun todos los criterios de busqueda
    private static ArrayList<Flight> searchFlights(String destination, String earliestDate,
                                                     String latestDate, String travelClass,
                                                     boolean wantsSmoker) {
        ArrayList<Flight> results = new ArrayList<>();

        for (Flight flight : flights) {
            if (!flight.isAvailable()) {
                continue;
            }

            // Compara el destino sin distinguir mayusculas
            if (!flight.getDestination().equalsIgnoreCase(destination)) {
                continue;
            }

            // Las fechas en formato AAAA-MM-DD se pueden comparar directamente
            if (flight.getDepartureDate().compareTo(earliestDate) < 0) {
                continue;
            }
            if (flight.getDepartureDate().compareTo(latestDate) > 0) {
                continue;
            }

            if (!flight.getTravelClass().equalsIgnoreCase(travelClass)) {
                continue;
            }

            // La seccion de fumadores solo se exige cuando el usuario la quiere
            if (wantsSmoker && !flight.hasSmokerSection()) {
                continue;
            }

            results.add(flight);
        }

        return results;
    }

    // Imprime la lista de vuelos que coinciden
    private static void showFlights(ArrayList<Flight> matches) {
        System.out.println("\n--- Vuelos disponibles ---");

        for (int i = 0; i < matches.size(); i++) {
            Flight flight = matches.get(i);
            System.out.println((i + 1) + ") Vuelo " + flight.getFlightNumber()
                    + " | Destino: " + flight.getDestination()
                    + " | Fecha: " + flight.getDepartureDate()
                    + " | Clase: " + flight.getTravelClass()
                    + " | Precio: $" + flight.getPrice()
                    + " | Seccion fumadores: " + (flight.hasSmokerSection() ? "Si" : "No"));
        }
    }

    // Pide nombre y documento para la reserva
    private static Passenger askPassengerData(Scanner scanner) throws InvalidInputException {
        System.out.println("\n--- Datos del pasajero ---");
        System.out.print("Nombre completo: ");
        String name = scanner.nextLine().trim();

        System.out.print("Documento de identidad: ");
        String documentId = scanner.nextLine().trim();

        return new Passenger(name, documentId);
    }

    // Imprime la informacion del boleto emitido
    private static void printTicket(Reservation reservation) {
        Flight flight = reservation.getFlight();
        Passenger passenger = reservation.getPassenger();

        System.out.println("\n========================================");
        System.out.println("         BOLETO EMITIDO");
        System.out.println("========================================");
        System.out.println("Reserva N°: " + reservation.getReservationId());
        System.out.println("Pasajero: " + passenger.getName());
        System.out.println("Documento: " + passenger.getDocumentId());
        System.out.println("Vuelo: " + flight.getFlightNumber());
        System.out.println("Destino: " + flight.getDestination());
        System.out.println("Fecha de salida: " + flight.getDepartureDate());
        System.out.println("Clase: " + flight.getTravelClass());
        System.out.println("Seccion: " + (reservation.isSmokerPreference() ? "Fumadores" : "No fumadores"));
        System.out.println("Precio: $" + flight.getPrice());
        System.out.println("========================================");
        System.out.println("Gracias por su reserva. Buen viaje!");
    }

    // Lee un numero entero del scanner, devuelve -1 si la entrada es invalida
    private static int readInt(Scanner scanner) {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
