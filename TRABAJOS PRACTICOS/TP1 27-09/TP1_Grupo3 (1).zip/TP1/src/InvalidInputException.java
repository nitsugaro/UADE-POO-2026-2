package grupo3.tp1.uade;

/**
 * Excepcion para datos ingresados incorrectamente (campos vacios, valores invalidos, etc.).
 */
public class InvalidInputException extends Exception {

    public InvalidInputException(String message) {
        super(message);
    }
}
