package grupo3.tp1.uade;

import java.util.Scanner;

/**
 * Punto de entrada principal del trabajo practico (TP1).
 */
public class Tp1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            showMainMenu();
            option = readInt(scanner, "Seleccione una opcion: ");

            switch (option) {
                case 1: {
                    try {
                        MeetingAgendaApp agendaApp = new MeetingAgendaApp();
                        agendaApp.run();
                    } catch (Exception e) {
                        System.out.println("Ocurrio un error inesperado en la agenda: " + e.getMessage());
                    }
                    break;
                }
                case 2:
                    try {
                        FlightReservationApp.run(scanner);
                    } catch (Exception e) {
                        System.out.println("Ocurrio un error inesperado en reservas: " + e.getMessage());
                    }
                    break;
                case 0:
                    System.out.println("Gracias por usar el sistema. Hasta luego!");
                    break;
                default:
                    System.out.println("Opcion invalida. Intente nuevamente.");
            }
        } while (option != 0);

        scanner.close();
    }

    private static void showMainMenu() {
        System.out.println();
        System.out.println("========== TP1 - Menu Principal ==========");
        System.out.println("1. Agenda de reuniones");
        System.out.println("2. Reserva de vuelos");
        System.out.println("0. Salir");
        System.out.println("==========================================");
    }

    // Lee un numero entero del usuario y maneja entradas invalidas
    private static int readInt(Scanner scanner, String message) {
        int value;
        while (true) {
            System.out.print(message);
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                scanner.nextLine();
                return value;
            } else {
                System.out.println("Debe ingresar un numero valido.");
                scanner.nextLine();
            }
        }
    }
}
