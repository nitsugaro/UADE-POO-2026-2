package grupo3.tp1.uade;

/**
 * Vincula un pasajero a una reserva de vuelo confirmada.
 */
public class Reservation {

    private int reservationId;
    private Flight flight;
    private Passenger passenger;
    private boolean smokerPreference;

    public Reservation(int reservationId, Flight flight, Passenger passenger, boolean smokerPreference)
            throws InvalidInputException {
        this.reservationId = reservationId;
        this.flight = flight;
        this.passenger = passenger;
        this.smokerPreference = smokerPreference;
        validate();
    }

    // Verifica que los datos de la reserva sean validos
    public void validate() throws InvalidInputException {
        if (reservationId <= 0) {
            throw new InvalidInputException("El numero de reserva debe ser mayor a 0.");
        }
        if (flight == null) {
            throw new InvalidInputException("El vuelo no puede ser nulo.");
        }
        if (passenger == null) {
            throw new InvalidInputException("El pasajero no puede ser nulo.");
        }
    }

    public int getReservationId() {
        return reservationId;
    }

    public Flight getFlight() {
        return flight;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public boolean isSmokerPreference() {
        return smokerPreference;
    }
}
