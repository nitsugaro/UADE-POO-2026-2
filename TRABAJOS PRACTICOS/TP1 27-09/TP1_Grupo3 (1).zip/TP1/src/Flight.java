package grupo3.tp1.uade;

/**
 * Representa un vuelo con informacion basica.
 */
public class Flight {

    private String flightNumber;
    private String destination;
    private String departureDate;
    private String travelClass;
    private boolean hasSmokerSection;
    private double price;
    private boolean available;

    public Flight(String flightNumber, String destination, String departureDate,
                  String travelClass, boolean hasSmokerSection, double price) throws InvalidInputException {
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.departureDate = departureDate;
        this.travelClass = travelClass;
        this.hasSmokerSection = hasSmokerSection;
        this.price = price;
        this.available = true;
        validate();
    }

    // Verifica que los datos del vuelo sean validos
    public void validate() throws InvalidInputException {
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            throw new InvalidInputException("El numero de vuelo no puede estar vacio.");
        }
        if (destination == null || destination.trim().isEmpty()) {
            throw new InvalidInputException("El destino no puede estar vacio.");
        }
        if (departureDate == null || departureDate.trim().isEmpty()) {
            throw new InvalidInputException("La fecha de salida no puede estar vacia.");
        }
        if (travelClass == null || travelClass.trim().isEmpty()) {
            throw new InvalidInputException("La clase no puede estar vacia.");
        }
        if (price <= 0) {
            throw new InvalidInputException("El precio debe ser mayor a 0.");
        }
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDestination() {
        return destination;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public boolean hasSmokerSection() {
        return hasSmokerSection;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}
