package grupo3.tp1.uade;

import java.util.ArrayList;

/**
 * Administra una coleccion de reuniones (agenda personal).
 */
public class Agenda {

    private ArrayList<Meeting> meetings;

    // Comienza con una lista vacia de reuniones
    public Agenda() {
        meetings = new ArrayList<>();
    }

    // Agrega una nueva reunion a la agenda
    public void addMeeting(Meeting meeting) throws InvalidInputException {
        if (meeting == null) {
            throw new InvalidInputException("La reunion no puede ser nula.");
        }
        meeting.validate();
        meetings.add(meeting);
    }

    // Devuelve todas las reuniones guardadas en la agenda
    public ArrayList<Meeting> getMeetings() {
        return meetings;
    }

    // Devuelve true si la agenda no tiene reuniones
    public boolean isEmpty() {
        return meetings.isEmpty();
    }

    // Busca reuniones cuyo tema contenga el texto dado (sin distinguir mayusculas)
    public ArrayList<Meeting> searchByTopic(String text) throws InvalidInputException {
        if (text == null || text.trim().isEmpty()) {
            throw new InvalidInputException("Debe ingresar un texto para buscar.");
        }

        ArrayList<Meeting> results = new ArrayList<>();
        String searchText = text.toLowerCase().trim();

        for (int i = 0; i < meetings.size(); i++) {
            Meeting meeting = meetings.get(i);
            if (meeting.getTopic().toLowerCase().contains(searchText)) {
                results.add(meeting);
            }
        }

        return results;
    }
}
