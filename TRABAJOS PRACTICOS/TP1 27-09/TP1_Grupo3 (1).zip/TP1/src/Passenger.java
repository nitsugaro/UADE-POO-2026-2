package grupo3.tp1.uade;

/**
 * Guarda los datos personales del pasajero para una reserva.
 */
public class Passenger {

    private String name;
    private String documentId;

    public Passenger(String name, String documentId) throws InvalidInputException {
        this.name = name;
        this.documentId = documentId;
        validate();
    }

    // Verifica que los datos del pasajero sean validos
    public void validate() throws InvalidInputException {
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidInputException("El nombre no puede estar vacio.");
        }
        if (documentId == null || documentId.trim().isEmpty()) {
            throw new InvalidInputException("El documento no puede estar vacio.");
        }
    }

    public String getName() {
        return name;
    }

    public String getDocumentId() {
        return documentId;
    }
}
